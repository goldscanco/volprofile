path = "~/Downloads/data/tickers_data/test.csv"
